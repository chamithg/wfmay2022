console.log("page loaded...");

var video = document.getElementById("myVideo");

function hover() {
  video.play();
}
function leave() {
  video.pause();
}
