console.log("man");

var cookie = document.getElementById("cookie");
function postAlert() {
  alert("Loading weather report");
}

function removeCookie() {
  cookie.remove();
}
