function printSeq(start, end) {
  for (i = start; i >= end; i -= 1.5) {
    console.log(i);
  }
}

printSeq(4, -4);
