function printOdds(number) {
  for (i = 1; i <= number; i++) {
    if (i % 2 == 0) {
      console.log(i);
    }
  }
}

printOdds(20);
